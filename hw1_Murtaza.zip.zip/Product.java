package prob1;

public class Product {
	private int	batch;
	private String code;
	private String	date;
	private int	indexDateBegins;
	private String	plant;


	public Product(String code){
		this.code = code;
		this.plant = extractPlant();
		this.date = extractDate();
		this.batch = extractBatch();
		
	
	}
	
	private int	extractBatch() {
		
	}
	private String	extractDate() {
		this.date = "";
		
	}
	private String	extractPlant() {
		this.plant = "";
        for(int i = 0; i < 3;i++) {
        	if(Character.isLetter(this.code.charAt(i))) {
        		this.plant += this.code.charAt(i);
        	}
        }
        return this.plant;
		
	}
	public int	getBatch() {
		return this.batch;
	}
	public String getCode() {
		return this.code;
	}
	public String getDate() {
		return this.date;
	}
	public String getPlant(){
		return this.plant;
	}
	public boolean isAfter2000() {
		String year = this.date.substring(6);
		if (Integer.parseInt(year) > 2000) {
			return true;
		}
		return false;
	}
	public boolean isMonthEqual(int month) {
		boolean isMonthEqual = true;
		String monthIN = this.date.substring(4,5);
		if(Integer.parseInt(monthIN) == month){
			return true;
		}
		return false;
		}
		
	}
	

}
